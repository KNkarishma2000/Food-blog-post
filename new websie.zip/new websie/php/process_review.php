<?php

// Establish a database connection
$conn = mysqli_connect('127.0.0.1', 'root', '', 'review form');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $review = $_POST["review"];

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO `user_review` (`name`, `email`, `review`) VALUES (?, ?, ?)");

    // Check if the statement was prepared successfully
    if ($stmt) {
        // Bind parameters to the statement
        $stmt->bind_param("sss", $name, $email, $review);

        // Execute the statement
        if ($stmt->execute()) {
            // Review inserted successfully, you can display a success message
            echo "Review submitted successfully!";
        } else {
            // Handle the case where the review insertion failed
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        // Handle the case where the statement preparation failed
        echo "Error: " . $conn->error;
    }
}

// Retrieve and display user reviews
$query = "SELECT * FROM `user_review` ORDER BY timestamp DESC";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<div class="comment-1">';
        echo '<img src="../img/icon.jpg">';
        echo '<div class="comment-text">';
        echo '<h2>' . $row["name"] . '</h2>';
        // Add code to display the rating here if you have it in the database
        echo '<p>' . $row["review"] . '</p>';
        echo '</div>';
        echo '</div>';
    }
} else {
    echo "No reviews yet.";
}

// Close the database connection
mysqli_close($conn);

?>
