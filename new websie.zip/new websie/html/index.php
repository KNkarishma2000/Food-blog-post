
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
        <meta name="viewport" content="width=device-width, initial-scale=1">
         
        <link rel="stylesheet" href="../css/style.css">
        <link rel="stylesheet" href="../css/sidebar.css">
        <link rel="stylesheet" href="../css/comment.css">
        <title>Food Blog</title>
    </head>
    <body>
        <section class="header">
            <div class="head">
                </div>
                <div class="hello">
                    <h2>Welcome To Our WebSite</h2>
                    <h3>Here You Can Find Best Restaurant</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ratione sapiente labore iste! Ipsum corporis necessitatibus temporibus nam quibusdam magni?</p>
                </div>
        </section>
     <section class="some-content">
         <div class="container-3">
            <div class="top-content">
               
            <div class="content">
             <h1> Top Restaurants In Hyderabad</h1>
             <p>Hyderabad, the capital of Telangana and de jure capital of Andhra Pradesh, is known, among other things, for its splendid Hyderabadi cuisine.The regional food consists of a wide array of rice,   wheat and meat dishes involving the use of various spices. With strong influences of Mughlai and Arab cuisines, the food in Hyderabad makes for a memorable experience for all who try it.Apart from local delights, the dining venues here also serve favourites from North India as well as other parts of the world. Here are some of the best restaurants in Hyderabad that are a must visit.
                Hyderabad is about students, working professionals and great opportunities.  </p>
             <img src="../img/almond.jpg">
            </div>

         </div>
            
           <div class="restaurant-3">
            <div class="restaurant-heading">
                <h1>Top Restaurant to Visit</h1>
                <div class="restaurant-button">
                    <button type="submit">View More</button>
                </div>
            </div>
            <div class="restaurant">
                <button id="shareButton" onclick="toggleShareOptions()">
                    <i class="fa fa-share"></i> Share
                </button>
                
                <div id="shareOptions">
                    <a href="#" class="share-option" onclick="shareOnTwitter()">
                        <i class="fa fa-twitter"></i>
                    </a>
                    <a href="#" class="share-icon" onclick="shareOnFacebook()">
                        <i class="fa fa-facebook"></i>
                    </a>
                    <a href="#" class="share-icon" onclick="shareOnInstagram()">
                        <i class="fa fa-instagram"></i>
                </div>
                <div class="restaurant-1">
                    <div class="restaurant-img">
                   <a href="#"><img src="../img/restaurant/1.webp"></a>
                     </div>
                     <div class="restaurant-text">
                       <a href="#"><h3>The Park</h3></a>
                        <p>Near Banjara Hills,Hyderabad</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus dignissimos voluptates ut fugiat suscipit corporis molestias, doloribus obcaecati voluptate esse.</p>
                        </div>
                </div>
                <div class="restaurant-1">
                    <div class="restaurant-img">
                        <a href="#"><img src="../img/restaurant/5be955b28b7e5f08c628bf1f_1542018482022.jpg"></a>
                    </div>
                    <div class="restaurant-text">
                        <a href="#"><h3>Vantage Cafe Bar</h3></a>
                    <p>Le Vantage Cafe Bar, Jubilee Hills, Hyderabad</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus dignissimos voluptates ut fugiat suscipit corporis molestias, doloribus obcaecati voluptate esse.</p>
                    </div>
                </div>
                <div class="restaurant-1">
                    <div class="restaurant-img">
                        <a href="#"><img src="../img/restaurant/64d37c34a8a4940ea79350de_1691581492450.jpg"></a>
                    </div>
                    <div class="restaurant-text">
                        <a href="#"><h3>Chicha's Restaurant</h3></a>
                        <p>Chicha's, Lakdi Ka Pul, Hyderabad</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus dignissimos voluptates ut fugiat suscipit corporis molestias, doloribus obcaecati voluptate esse.</p>
                        </div>
                </div>
                <div class="restaurant-1">
                    <div class="restaurant-img">
                        <a href="#"><img src="../img/restaurant/5be955b28b7e5f08c628bf1f_1542018482022.jpg"></a>
                    </div>
                    <div class="restaurant-text">
                        <a href="#"><h3>Cafe Bahar</h3></a>
                        <p>Cafe Bahar, Himayath Nagar, Hyderabad</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus dignissimos voluptates ut fugiat suscipit corporis molestias, doloribus obcaecati voluptate esse.</p>
                        </div>
                </div>
            </div>
            
           
        </div>
            <div class="container">
                <div class="browery-title">
                    <h2>Top Broweries Restaurant</h2>
                    <div class="browery-button">
                        <button type="submit">View More</button>
                    </div>
                </div>
                <div class="top-broweries">
                    <div class="box">
                       <a href="#"><img src="../img/top brow/56.webp"></a>
                         <div class="box-content">
                           <a href="#"><h1>The Lasania Park</h1></a>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                         </div>
                    </div>
                    <div class="box">
                        <a href="#"><img src="../img/top brow/eazytrendz_2627_trend20191107091424.jpg"></a>
                         <div class="box-content">
                            <a href="#"><h1>The Lasania Park</h1></a>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                         </div>
                    </div>
                    <div class="box">
                        <a href="#"><img src="../img/top brow/oll17gqttn.webp"></a>
                         <div class="box-content">
                            <a href="#"><h1>Tatva</h1></a>
                            <p>1st Floor, SL Jubilee, Road 36, Jubilee Hills, Hyderabad</p>
                         </div>
                    </div>
                    <div class="box">
                        <a href="#"><img src="../img/top brow/um6o1ugx7nk.webp"></a>
                         <div class="box-content">
                            <a href="#"><h1>The Spicy Venue</h1></a>
                            <p>Door 8-2-293/82/A/265-S, Road 10, Jubilee Hills, Hyderabad</p>
                         </div>
                    </div>
                </div>
            </div>
            <div class="dining">
                <div class="dining-heading">
                    <h2>Top Dining Restaurants</h2>
                    <div class="dining-button">
                        <button type="submit">View More</button>
                    </div>
                </div>
                <div class="dinings">
                    <div class="dining-rest">
                        <a href="#"><img src="../img/restaurant/1.webp"></a>
                          <div class="dining-content">
                            <a href="#"><h1>The Lasania Park</h1></a>
                             <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                          </div>
                     </div>
                     <div class="dining-rest">
                         <a href="#"><img src="../img/restaurant/5be955b28b7e5f08c628bf1f_1542018482022.jpg"></a>
                          <div class="dining-content">
                             <a href="#"><h1>The Lasania Park</h1></a>
                             <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                          </div>
                     </div>
                     <div class="dining-rest">
                         <a href="#"><img src="../img/restaurant/gfds.webp"></a>
                          <div class="dining-content">
                             <a href="#"><h1>The Lasania Park</h1></a>
                             <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                          </div>
                     </div>
                     <div class="dining-rest">
                         <a href="#"><img src="../img/restaurant/64d37c34a8a4940ea79350de_1691581492450.jpg"></a>
                          <div class="dining-content">
                             <a href="#"><h1>The Lasania Park</h1></a>
                             <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                          </div>
                     </div>
                </div>
            </div>
           
           
         </div>
            <div class="side-bar">
                <div class="container-2">
                    <div class="information">
                        <div class="information-text">
                            <h1>Welcome To Our Blog</h1>
                            <p>Hyderabad, the capital of Telangana and de jure capital of Andhra Pradesh, is known, among other things, for its splendid Hyderabadi cuisine. The regional food consists of a wide array of rice, wheat and meat dishes involving the use of various spices.</p>
                            <img src="../img/almond.jpg">
                        </div>
                     
                    </div>
                    <div class="blog">
                        <div class="blog-heading">
                            <h2>Trending Recipes</h2>
                        </div>
                        <div class="blogs">
                            <div class="blog-1">
                                <a href="#"><img src="../img/blog/images (1).jpg"></a>
                        </div>
                        <div class="blog-1">
                            <a href="#"><img src="../img/blog/FRESH_PA_i1140.jpg"></a>
                        </div>
                        <div class="blog-1">
                            <a href="#"><img src="../img/blog/images.jpg"></a>
                         </div>
                        <div class="blog-1">
                            <a href="#"><img src="../img/blog/photo.webp"></a>
                        </div>
                        <div class="blog-1">
                            <a href="#"><img src="../img/blog/images (2).jpg"></a>
                        </div>
                        <div class="blog-1">
                            <a href="#"><img src="../img/blog/images (3).jpg"></a>
                        </div>

                    </div>
                </div>
            </div>
        </section>
        <section class="review-section">
            
            <div class="review">
                <div class="title-heading">
                    <h2>Review</h2>
                </div>
                <div class="review-back">

                </div>
               <form action="index.php" method="POST" class="review-form">
                    <input type="text" placeholder="Name..." name="name"><br>
                    <input type="text" placeholder="Email..." name="email"><br>
                    <input type="textarea" placeholder="Write Your Review" name="review"><br>
                    <button type="submit" placeholder="Review">Submit</button>
               </form>
            </div>
        </section>
        <section class="comment" style="transform:translateY(60%);">
            <div class="comment-heading">
                <h3>Comments</h3>
            </div>
            <div class="comments">
               
                
                <div class="comment-1">
                   <img src="../img/icon.jpg">
                    <div class="comment-text">
                    <h2>Anonymous</h2>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor ad assumenda ea eum corporis odio qui excepturi iusto consequuntur placeat!</p>
                  </div>
                 </div>
                <div class="comment-1 comment-2">
                    <img src="../img/icon.jpg">
                    <div class="comment-text">
                    <h2>Anonymous</h2>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor ad assumenda ea eum corporis odio qui excepturi iusto consequuntur placeat!</p>
                </div>
                </div>
                <div class="comment-1">
                    <img src="../img/icon.jpg">
                    <div class="comment-text">
                    <h2>Anonymous</h2>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor ad assumenda ea eum corporis odio qui excepturi iusto consequuntur placeat!</p>
                </div>

                </div>
                <?php

// Establish a database connection
$conn = mysqli_connect('127.0.0.1', 'root', '', 'review form');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $review = $_POST["review"];

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO `user_review` (`name`, `email`, `review`) VALUES (?, ?, ?)");

    // Check if the statement was prepared successfully
    if ($stmt) {
        // Bind parameters to the statement
        $stmt->bind_param("sss", $name, $email, $review);

        // Execute the statement
        // if ($stmt->execute()) {
         
        //     echo "Review submitted successfully!";
        // } else {
          
        //     echo "Error: " . $stmt->error;
        // }

        // Close the statement
        $stmt->close();
    } else {
        // Handle the case where the statement preparation failed
        echo "Error: " . $conn->error;
    }
}

// Retrieve and display user reviews
$query = "SELECT * FROM `user_review` ORDER BY timestamp DESC";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<div class="comment-1">';
        echo '<img src="../img/icon.jpg">';
        echo '<div class="comment-text">';
        echo '<h2>' . $row["name"] . '</h2>';
        echo'<div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>';
        // Add code to display the rating here if you have it in the database
        echo '<p>' . $row["review"] . '</p>';
        echo '</div>';
        echo '</div>';
    }
} else {
    echo "No reviews yet.";
}

// Close the database connection
mysqli_close($conn);

?>
            </div>
        </section>
        
        <div class="user-points">
            <i class="fas fa-coins"></i> <span id="userPoints"><?php echo isset($_SESSION['userPoints']) ? $_SESSION['userPoints'] : 0; ?></span>
        </div>
        <script src="../js/loyality.js"></script>
    </body>
</html>