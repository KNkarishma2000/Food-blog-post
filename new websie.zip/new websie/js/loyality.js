function toggleShareOptions() {
  const shareOptions = document.getElementById('shareOptions');
  if (shareOptions.style.display === 'block') {
      shareOptions.style.display = 'none';
  } else {
      shareOptions.style.display = 'block';
  }
}

// Initialize user points (you can set this to the initial value)
let userPoints = 0;

// Function to update and display user points
function updateUserPoints(points) {
  userPoints += points; // Update user points
  const userPointsElement = document.getElementById('userPoints');
  userPointsElement.textContent = userPoints; // Display updated points
}

// Function to handle Facebook sharing
function shareOnFacebook() {
  const blogPostUrl = encodeURIComponent("YOUR_BLOG_POST_URL");
  const facebookShareUrl = `https://www.facebook.com/sharer/sharer.php?u=https://corporatemirrors.com/`;

  // Open the Facebook share dialog in a new window/tab
  window.open(facebookShareUrl, '_blank');

  // Increase points by 1 when the user clicks on Facebook share
  updateUserPoints(1);
}

// Function to handle Instagram sharing
function shareOnInstagram() {
  const blogPostUrl = encodeURIComponent("YOUR_BLOG_POST_URL");
  const instagramShareUrl = `https://www.instagram.com/?url=${blogPostUrl}`;

  // Open the Instagram share dialog in a new window/tab
  window.open(instagramShareUrl, '_blank');

  // Increase points by 1 when the user clicks on Instagram share
  updateUserPoints(1);
}

function updateUserPoints(points) {
    // Send an AJAX request to update points on the server
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `update_points.php?points=${points}`, true);
    xhr.send();

    // Update points on the page
    const userPointsElement = document.getElementById('userPoints');
    userPointsElement.textContent = parseInt(userPointsElement.textContent) + points;
}

function addPoint() {
    updateUserPoints(1);
}
